import { useContext, useState } from "react";
import { Routes, Route, NavLink } from "react-router-dom";
import Users from "../pages/Users";
import Home from "../pages/Home";
import Reg from "../pages/Reg";
import Profile from "../pages/Profile";
import { UserContext } from "../context/UserContext";
import ChatPage from "../pages/ChatPage";

const Nav = () => {
  const { user, authLoading } = useContext(UserContext);
  const [menuOpen, setMenuOpen] = useState(false);

  const closeMenu = () => setMenuOpen(false);
  const linkClass = ({ isActive }) =>
    `app-nav__link${isActive ? " app-nav__link--active" : ""}`;

  return (
    <>
      <header className="app-header">
        <div className="logo">
          <NavLink to="/" className="logo-link" onClick={closeMenu}>
            <span className="logo-mark" aria-hidden="true">
              <span className="logo-mark__bubble logo-mark__bubble--front" />
              <span className="logo-mark__bubble logo-mark__bubble--back" />
            </span>
            <span className="logo-wordmark">
              Chat <strong>App</strong>
            </span>
          </NavLink>
        </div>
        <button
          type="button"
          className="app-nav__toggle"
          aria-label={
            menuOpen ? "Close navigation menu" : "Open navigation menu"
          }
          aria-expanded={menuOpen}
          aria-controls="main-navigation"
          onClick={() => setMenuOpen((open) => !open)}
        >
          <span />
          <span />
          <span />
        </button>
        <nav
          id="main-navigation"
          className={`app-nav${menuOpen ? " app-nav--open" : ""}`}
          aria-label="Main navigation"
        >
          <NavLink to="/" className={linkClass} onClick={closeMenu}>
            Home
          </NavLink>
          <NavLink to="/users" className={linkClass} onClick={closeMenu}>
            Search Friends
          </NavLink>
          {authLoading ? (
            <span className="app-nav__status">Loading...</span>
          ) : user ? (
            <NavLink
              to="/profile"
              className={(state) => `${linkClass(state)} app-nav__account`}
              onClick={closeMenu}
            >
              {user.userName}
            </NavLink>
          ) : (
            <NavLink to="/reg" className={linkClass} onClick={closeMenu}>
              Sign In
            </NavLink>
          )}

          <NavLink to="/chat" className={linkClass} onClick={closeMenu}>
            Chats
          </NavLink>
        </nav>
      </header>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/reg" element={<Reg />} />
        <Route path="/users" element={<Users />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/chat" element={<ChatPage />} />
      </Routes>
    </>
  );
};

export default Nav;
