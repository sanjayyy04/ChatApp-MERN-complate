import React, { useState } from "react";
import { FiPaperclip, FiSend } from "react-icons/fi";

const Chat = () => {
  const [message, setMessage] = useState("");

  const handleChange = (e) => {
    setMessage(e.target.value);
  };

  const handleMessageSend = (e) => {
    e.preventDefault();

    console.log("message sent:", message);

    setMessage("");
  };

  return (
    <main className="chat-page">
      <section className="chat-panel" aria-label="Chat conversation">
        <h1>Chats</h1>
        <form className="chat-composer" onSubmit={handleMessageSend}>
          <input
            className="chat-composer__input"
            type="text"
            placeholder="Write a message..."
            value={message}
            onChange={handleChange}
            aria-label="Message"
          />
          <button
            type="submit"
            className="chat-composer__send"
            aria-label="Send message"
          >
            <FiSend aria-hidden="true" />
          </button>
        </form>
      </section>
    </main>
  );
};

export default Chat;
